package labo7.commands;

public interface Invoker {
    void storeCommand(Command command);
}
